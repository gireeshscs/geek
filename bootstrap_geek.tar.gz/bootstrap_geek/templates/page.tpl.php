<body onload="load()">
	<div id="main-div" class="container-fluid">
		<div id="section-one" class="row">
			<div class="section-one text-center center-block sizefull">
				<div class="content-top">
					<div class="logo">
					<?php if ($logo):?>
            <a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" rel="home"> <img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" /> </a>
                <?php endif; ?>
						<!--<img class="center-block img-responsive" src="images/logo.png">-->
					</div>
					<?php if ($page['top_content']):?>
					<?php print render($page['top_content']); ?>
					<?php endif; ?>
				</div>
				<div class="content-bottom">
					<a href="#section-two" class="scrollnext nav center-block img-circle" role="section-two"></a>
				</div>
			</div>
		</div>
		<div id="section-two" class="row">
			<div class="section-two text-center center-block sizefull">
				<div class="content-top">
					<div class="logo">
						<img class="center-block" src="<?php print $base_path?>/<?php print $directory;?>/images/image1.png">
					</div>
					<!--<h3 class="sub-title text-center imageone-txt">-->
					<?php if ($page['middle_content_1']):?>
					<?php print render($page['middle_content_1']); ?>
					<?php endif; ?>
					<!--</h3>-->
				</div>
				<div class="content-bottom">
					<a href="#section-three" class="scrollnext nav center-block img-circle" role="section-two"></a>
				</div>
			</div>
		</div>
		<div id="section-three" class="row">
			<div class="section-three text-center center-block sizefull">
				<div class="content-top">
					<div class="logo">
						<img class="center-block" src="<?php print $base_path?>/<?php print $directory;?>/images/image2.png">
					</div>
					<!--<h3 class="sub-title text-center imageone-txt">-->
					<?php if ($page['middle_content_2']):?>
					<?php print render($page['middle_content_2']); ?>
					<?php endif; ?>
					<!--</h3>-->
					
				</div>
				<div class="content-bottom">
					<a href="#section-four" class="scrollnext nav center-block img-circle" role="section-two"></a>
				</div>
			</div>
		</div>
		<div id="section-four" class="row">
			<div class="section-four text-center center-block sizefull">
				<div class="content-top">
					<div class="logo">
						<img class="center-block" src="<?php print $base_path?>/<?php print $directory;?>/images/image3.png">
					</div>
					<!--<h3 class="sub-title text-center imageone-txt">-->
					<?php if ($page['middle_content_3']):?>
					<?php print render($page['middle_content_3']); ?>
					<?php endif; ?>
					<!--</h3>-->
				</div>
				<div class="content-bottom">
					<a href="#section-five" class="scrollnext nav center-block img-circle" role="section-two"></a>
				</div>
			</div>
		</div>
		<div id="section-five" class="row">
			<div class="section-five text-center center-block sizefull">
				<div class="content-top">
					<h1 class="content-title">Services</h1>
						<div class="services-container center-block">
							<div class="col-lg-3 col-md-3 col-xs-12 col-sm-6 circle-block">
								<div class="img-circle circle">
									<img class="center-block" src="<?php print $base_path?>/<?php print $directory;?>/images/service.png">
									<?php //if ($page['services_logo_left']):?>
									<?php //print render($page['services_logo_left']); ?>
									<?php //endif; ?>
								</div>
								
								<?php if ($page['service_left']):?>
									<?php print render($page['service_left']); ?>
									<?php endif; ?>
	
							</div>
							<div class="col-lg-3 col-md-3 col-xs-12 col-sm-6 circle-block">
								<div class="img-circle circle">
									<img class="center-block" src="<?php print $base_path?>/<?php print $directory;?>/images/design.png">
								</div>
								
								<?php if ($page['service_middle_left']):?>
									<?php print render($page['service_middle_left']); ?>
									<?php endif; ?>
							
							</div>
							<div class="col-lg-3 col-md-3 col-xs-12 col-sm-6 circle-block">
								<div class="img-circle circle">	
									<img class="center-block" src="<?php print $base_path?>/<?php print $directory;?>/images/branding.png">
								</div>
								
								<?php if ($page['service_middle_right']):?>
									<?php print render($page['service_middle_right']); ?>
									<?php endif; ?>
								
							</div>
							<div class="col-lg-3 col-md-3 col-xs-12 col-sm-6 circle-block">
								<div class="img-circle circle">
									<img class="center-block" src="<?php print $base_path?>/<?php print $directory;?>/images/uxresearch.png">
								</div>
								
								<?php if ($page['service_right']):?>
									<?php print render($page['service_right']); ?>
									<?php endif; ?>
							
							</div>
							
						</div>
					
				</div>
				<div class="content-bottom">
					<a href="#section-six" class="scrollnext nav center-block img-circle" role="section-two"></a>
				</div>
			</div>
		</div>
		  <?php print render($page['content']); ?>
		<div id="section-six" class="row">
			<div class="section-six text-center center-block sizefull">
				<div class="content-top">
					<h1 class="content-title">Clients</h1>
						<div class="container center-block">
						
						<?php if ($page['clients']):?>
									<?php print render($page['clients']); ?>
									<?php endif; ?>
							
							<!--logo carosal-->
							<!--<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
							<ol class="carousel-indicators visible-xs">
								<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
								<li data-target="#carousel-example-generic" data-slide-to="1"></li>
								<li data-target="#carousel-example-generic" data-slide-to="2"></li>
							</ol>

							 <!-- Wrapper for slides -->
							  <!--<div class="carousel-inner" role="listbox">
								<div class="item active">
									<div class="row">
										<div class="col-lg-4 col-md-4 col-xs-12 col-sm-4">
											<img class="logoimg img-responsive" src="images/logo1.png" />
										</div>
										<div class="col-lg-4 col-md-4 col-sm-4 hidden-xs">
											<img class="logoimg img-responsive" src="images/logo2.png">
										</div>
										<div class="col-lg-4 col-md-4 col-sm-4  hidden-xs">
											<img class="logoimg img-responsive" src="images/logo3.png"  />
										</div>
									</div>
								</div>
								<div class="item">
									<div class="row">
										<div class="col-lg-4 col-md-4 col-sm-4 hidden-xs">
											<img class="logoimg img-responsive" src="images/logo1.png" />
										</div>
										<div class="col-lg-4 col-md-4 col-xs-12 col-sm-4">
											<img class="logoimg img-responsive" src="images/logo2.png">
										</div>
										<div class="col-lg-4 col-md-4 col-sm-4 hidden-xs">
											<img class="logoimg img-responsive" src="images/logo3.png"  />
										</div>
									</div>
								</div>
								<div class="item">
									<div class="row">
										<div class="col-lg-4 col-md-4 col-sm-4 hidden-xs">
											<img class="logoimg img-responsive" src="images/logo1.png" />
										</div>
										<div class="col-lg-4 col-md-4 col-sm-4 hidden-xs">
											<img class="logoimg img-responsive" src="images/logo2.png">
										</div>
										<div class="col-lg-4 col-md-4 col-xs-12 col-sm-4">
											<img class="logoimg img-responsive" src="images/logo3.png"  />
										</div>
									</div>
								</div>
							  </div>
							  					 
							  <!-- Controls -->
							  <!--<a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
								<span class="" aria-hidden="true"><img class=" img-responsive leftarrow" src="images/left.png" /></span>
								<span class="sr-only">Previous</span>
							  </a>
							  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
								<span class="" aria-hidden="true"><img class=" img-responsive rightarrow" src="images/right.png" /></span>
								<span class="sr-only">Next</span>
							  </a>
							</div>
							<!--logo carosal end-->
							
						</div>
					
				</div>
				<div class="content-bottom">
					<a href="#section-seven" class="scrollnext nav center-block img-circle" role="section-two"></a>
				</div>
			</div>
		</div>
		<div id="section-seven" class="row">
			<div class="section-seven text-center center-block sizefull">
				<div class="content-top">
					<h1 class="content-title">How to find us</h1>
						<div class="map-container center-block">
						 
							<div id="map" class="map"></div>
							<div id="shadow" class=""></div>
							
						</div>
					
				</div>
				<div class="content-bottom">
					<a href="#section-eight" class="scrollnext nav center-block img-circle" role="section-two"></a>
				</div>
			</div>
		</div>
		<div id="section-eight" class="row">
			<div class="section-eight text-center center-block sizefull">
				<div class="content-top">
					<h1 class="content-title">Contact</h1>
						<div class="contact-container center-block">
							
                    <div class="form-group">
                        <div>
                            <input type="text" name="" class="form-control contact_form" placeholder="Name">
                        </div>
                    </div>
                    <div class="form-group">
                        <div>
                            <input type="text" name="" class="form-control contact_form" placeholder="Email">
                        </div>
                    </div>
                    <div class="form-group">
                        <div>
                            <textarea cols="70"  class="form-control contact_form_textarea" placeholder="Message"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <div>
                            <input type="button" name="" class="contact_form_button" value="Send Message!">
                        </div>
                    </div>
                    <div class="rowone">
                        <div class="contact_form_no hidden-xs">
                            Or  phone on : 01923 220121
							<br />
							<br />
							<br />
							<br />
							<br />
                        </div>
						<div class="contact_form_no mobile visible-xs">
                            <span class="glyphicon glyphicon-earphone"></span>01923 220121 <br />
							<span class="glyphicon glyphicon-envelope"></span>info@compucorp.co.uk <br />
                        </div>
                    </div>
                </div>
							
						</div>
					
				</div>
			</div>
		</div>
		
	</div>